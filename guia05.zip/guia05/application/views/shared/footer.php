		<div class="container text-right">
			<p class="d-inline">
				<strong> Derechos reservados - Universidad de Sonsonate &copy; 2021</strong>
			</p>
		</div>
	</body>
</html>